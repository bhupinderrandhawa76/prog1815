﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[,] seat= new string[5, 3];

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                seat[0, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                seat[0, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                seat[0, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                seat[1, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                seat[1, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                seat[1, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                seat[2, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                seat[2, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                seat[2, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                seat[3, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                seat[3, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                seat[3, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                seat[4, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                seat[4, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                seat[4, 2] = textBox1.Text;
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {

            richTextBox1.Text = "";
            richTextBox1.Text = richTextBox1.Text += seat[0, 0] ;
            richTextBox1.Text = richTextBox1.Text += seat[0, 1] ;
            richTextBox1.Text = richTextBox1.Text += seat[0, 2] ;
            richTextBox1.Text = richTextBox1.Text += seat[1, 0] ;
            richTextBox1.Text = richTextBox1.Text += seat[1, 1] ;
            richTextBox1.Text = richTextBox1.Text += seat[1, 2] ;
            richTextBox1.Text = richTextBox1.Text += seat[2, 0] ;
            richTextBox1.Text = richTextBox1.Text += seat[2, 1] ;
            richTextBox1.Text = richTextBox1.Text += seat[2, 2] ;
            richTextBox1.Text = richTextBox1.Text += seat[3, 0] ;
            richTextBox1.Text = richTextBox1.Text += seat[3, 1] ;
            richTextBox1.Text = richTextBox1.Text += seat[3, 2] ;
            richTextBox1.Text = richTextBox1.Text += seat[4, 0] ;
            richTextBox1.Text = richTextBox1.Text += seat[4, 1] ;
            richTextBox1.Text = richTextBox1.Text += seat[4, 2] ;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                if (seat[0, 0] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                if (seat[0, 1] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                if (seat[0, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                if (seat[1, 0] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                if (seat[1, 1] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                if (seat[1,2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                if (seat[1, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                seat[0, 0] = "";
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                seat[0, 1] = "";
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                seat[0, 2] = "";
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                seat[1, 0] = "";
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                seat[1, 1] = "";
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                seat[1, 2] = "";

            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                seat[2, 0] = "";
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                seat[2, 1] = "";
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                seat[2, 2] = "";
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                seat[3, 0] = "";
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                seat[3, 1] = "";
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                seat[3, 2] = "";
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                seat[4, 0] = "";
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                seat[4, 1] = "";
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                seat[4, 2] = "";
            }
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                seat[0, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                seat[0, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                seat[0, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                seat[1, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                seat[1, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                seat[1, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                seat[2, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                seat[2, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                seat[2, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                seat[3, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                seat[3, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                seat[3, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                seat[4, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                seat[4, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                seat[4, 2] = textBox1.Text;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            richTextBox2.Text = "";
            richTextBox2.Text = richTextBox2.Text += seat[0, 0] ;
            richTextBox2.Text = richTextBox2.Text += seat[0, 1] ;
            richTextBox2.Text = richTextBox2.Text += seat[0, 2] ;
            richTextBox2.Text = richTextBox2.Text += seat[1, 0] ;
            richTextBox2.Text = richTextBox2.Text += seat[1, 1] ;
            richTextBox2.Text = richTextBox2.Text += seat[1, 2] ;
            richTextBox2.Text = richTextBox2.Text += seat[2, 0] ;
            richTextBox2.Text = richTextBox2.Text += seat[2, 1] ;
            richTextBox2.Text = richTextBox2.Text += seat[2, 2] ;
            richTextBox2.Text = richTextBox2.Text += seat[3, 0] ;
            richTextBox2.Text = richTextBox2.Text += seat[3, 1] ;
            richTextBox2.Text = richTextBox2.Text += seat[3, 2] ;
            richTextBox2.Text = richTextBox2.Text += seat[4, 0] ;
            richTextBox2.Text = richTextBox2.Text += seat[4, 1] ;
            richTextBox2.Text = richTextBox2.Text += seat[4, 2] ;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button22_Click(object sender, EventArgs e)
        {
           
            {
                richTextBox1.Text= seat[0, 0] = "Booked";
                richTextBox1.Text = seat[0, 1] = "Booked";
                richTextBox1.Text = seat[0, 2] = "Booked";
                richTextBox1.Text = seat[1, 0] = "Booked";
                richTextBox1.Text = seat[1, 1] = "Booked";
                richTextBox1.Text = seat[1, 2] = "Booked";
                richTextBox1.Text = seat[2, 0] = "Booked";
                richTextBox1.Text = seat[2, 1] = "Booked";
                richTextBox1.Text = seat[2, 2] = "Booked";
                richTextBox1.Text = seat[3, 0] = "Booked";
                richTextBox1.Text = seat[3, 1] = "Booked";
                richTextBox1.Text = seat[3, 2] = "Booked";
                richTextBox1.Text = seat[4, 0] = "Booked";
                richTextBox1.Text = seat[4, 1] = "Booked";
                richTextBox1.Text = seat[4, 2] = "Booked";
            }
        }

        
    }
}
